package schema

//go:generate go run github.com/sensu/sensu-go/scripts/gengraphql .
