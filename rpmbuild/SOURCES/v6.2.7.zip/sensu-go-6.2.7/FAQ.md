# Sensu Go Frequently Asked Questions (FAQ)

Please see https://docs.sensu.io/sensu-go/latest/getting-started/faq/
