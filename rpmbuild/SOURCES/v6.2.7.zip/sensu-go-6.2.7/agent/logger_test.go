package agent

func init() {
	//logrus.SetLevel(logrus.DebugLevel)
}
