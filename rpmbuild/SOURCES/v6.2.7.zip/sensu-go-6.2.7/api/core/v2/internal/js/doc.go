// Package js provides facilities based on the Otto VM for parsing and
// executing javascript expressions.
package js
